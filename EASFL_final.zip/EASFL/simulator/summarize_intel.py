"""Tables for the Intel Lab real-data experiment (results_intel.json)."""
import json, sys
import numpy as np

R = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'results_intel.json'))


def ms(v, d=3):
    v = np.array(v, float)
    return f"{v.mean():.{d}f}±{v.std():.{d}f}"


print("== Table I1: detection after 200 rounds on the Intel Lab deployment (mean±std over 5 seeds)")
for name, key in [('Centralized', 'central'), ('Local only', 'local')]:
    xs = R[key]
    print(f"{name:13s} F1(G)={ms([x['final']['global']['f1'] for x in xs])} AUC={ms([x['final']['global']['auc'] for x in xs])} "
          f"F1(thr)={ms([x['final']['thr']['f1'] for x in xs])}")
for sc in ['FL-flat', 'FL-LEACH', 'EASFL']:
    xs = [x for x in R['learn'] if x['scheme'] == sc]
    f = lambda k, m='f1': [x['final'][k][m] for x in xs]
    print(f"{sc:13s} F1(G)={ms(f('global'))} AUC={ms(f('global', 'auc'))} F1(P)={ms(f('ft+thr'))} "
          f"Net F1={ms(f('net'))} Mbit={ms([x['mbit'] for x in xs], 1)} alive@200={ms([x['alive'] for x in xs], 1)}")

print("\n== Table I2: global-model F1 with 20% malicious nodes")
cfgs = [('FedAvg (mean)', 'FL-LEACH', None), ('Median', 'FL-LEACH', 'median'), ('Trimmed mean', 'FL-LEACH', 'trimmed'),
        ('Krum', 'FL-LEACH', 'krum'), ('EASFL', 'EASFL', None)]
for a in ['signflip', 'stealth', 'labelflip', 'gauss']:
    row = []
    for lab, sc, agg in cfgs:
        xs = [x for x in R['attack'] if x['scheme'] == sc and x['kw'].get('attack') == a and x['kw'].get('agg') == agg]
        row.append(f"{lab}={np.mean([x['final']['global']['f1'] for x in xs]):.2f}")
    print(f"{a:10s} " + '  '.join(row))

print("\n== Table I3: lifetime (rounds) and energy per node per round on the Intel Lab deployment")
for rad in ['first-order', 'CC2420', 'CC2650']:
    for sc, pd in [('CL', False), ('FL-flat', False), ('FL-LEACH', False), ('EASFL', False), ('EASFL', True)]:
        xs = [x for x in R['life'] if x['radio'] == rad and x['scheme'] == sc and x['kw'].get('pd', False) == pd]
        e = np.mean([sum(x['energy'].values()) for x in xs])
        lab = sc + ('-PD' if pd else '')
        print(f"{rad:12s} {lab:9s} FND={np.mean([x['fnd'] for x in xs]):7.1f} HND={np.mean([x['hnd'] for x in xs]):7.1f} "
              f"LND={np.mean([x['lnd'] for x in xs]):7.1f} E={1e3 * e:7.3f} mJ")
