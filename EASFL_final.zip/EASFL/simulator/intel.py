"""Intel Berkeley Research Lab deployment (54 Mica2Dot motes, Feb 28 - Apr 5, 2004).

Real temperature, humidity, light and voltage readings, real mote positions and measured
mote-to-mote and mote-to-base-station delivery probabilities. Faults of the four types used in the
synthetic workload are injected into the real readings to obtain ground-truth labels.

Data: http://db.csail.mit.edu/labdata/labdata.html  (data.txt.gz, mote_locs.txt, connectivity.txt).
Run once:  python intel.py /path/to/data.txt.gz /path/to/mote_locs.txt /path/to/connectivity.txt
which writes intel_windows.npz (cleaned, windowed readings) and intel_net.npz (deployment).
"""
import sys
import numpy as np
from common import WIN, CH_SCALE, features, make_node_profiles

T_END = '2004-03-10'          # first ten days: dense, before battery decay corrupts readings
MAX_SPAN = 2.5 * WIN * 31.0   # s; 10 consecutive readings (31 s period) with a few missing epochs allowed
N_TRAIN, N_TEST = 200, 100
MIN_WINDOWS = 600             # motes with fewer clean windows in the period are excluded


def preprocess(data_path, locs_path, conn_path):
    import pandas as pd
    df = pd.read_csv(data_path, sep=r'\s+', header=None, on_bad_lines='skip',
                     names=['date', 'time', 'epoch', 'mote', 'T', 'H', 'L', 'V']).dropna()
    df['ts'] = pd.to_datetime(df.date + ' ' + df.time, errors='coerce', format='mixed')
    df = df.dropna(subset=['ts'])
    df = df[df.ts < T_END]
    ok = df['T'].between(10, 40) & df['H'].between(0, 100) & df['V'].between(2.0, 3.2) & (df['L'] >= 0)
    df = df[ok].copy(); df['mote'] = df['mote'].astype(int)
    df = df.sort_values(['mote', 'ts'])
    t_ref = pd.Timestamp('2004-02-28')
    motes, W, Wt = [], {}, {}
    for m, g in df.groupby('mote'):
        if not 1 <= m <= 54:
            continue
        X = g[['T', 'H', 'L', 'V']].values; t = (g.ts - t_ref).dt.total_seconds().values
        n = len(X) // WIN
        X = X[:n * WIN].reshape(n, WIN, 4); t = t[:n * WIN].reshape(n, WIN)
        good = (t[:, -1] - t[:, 0]) <= MAX_SPAN
        if good.sum() >= MIN_WINDOWS:
            motes.append(m); W[m] = X[good]; Wt[m] = t[good, 0]
    np.savez_compressed('intel_windows.npz', motes=np.array(motes),
                        **{f'X{m}': W[m] for m in motes}, **{f't{m}': Wt[m] for m in motes})
    locs = np.loadtxt(locs_path)
    pos = np.array([locs[locs[:, 0] == m, 1:][0] for m in motes])
    rows = [l.split() for l in open(conn_path) if len(l.split()) == 3]
    C = np.array(rows, float)
    P = np.zeros((55, 55))
    for s, r, p in C:
        P[int(s), int(r)] = p
    idx = np.array(motes)
    link = P[np.ix_(idx, idx)]
    link_bs = P[idx, 0]
    w = link_bs ** 4                                  # base station placed where links to it are best
    bs = (pos * w[:, None]).sum(0) / w.sum()
    np.savez_compressed('intel_net.npz', motes=idx, pos=pos, link=link, link_bs=link_bs, bs=bs)
    print(f'{len(motes)} motes kept; windows per mote: min {min(len(W[m]) for m in motes)}; BS at {bs.round(1)}')


def load_net():
    z = np.load('intel_net.npz')
    return dict(pos=z['pos'], bs=z['bs'], link=z['link'], link_bs=z['link_bs'], ch_sep=10.0, deg_r=10.0)


def inject(rng, X, p):
    """Inject faults into real windows X (n, WIN, 4) with the synthetic generator's fault process."""
    X = X.copy(); n = len(X)
    y = (rng.random(n) < p['rate']).astype(int)
    for w in np.where(y)[0]:
        kind = rng.choice(4, p=p['mix']); c = rng.integers(4)
        amp = rng.uniform(3, 8) * CH_SCALE[c]
        if kind == 0:
            X[w, rng.integers(WIN), c] += amp * rng.choice([-1, 1])
        elif kind == 1:
            X[w, :, c] = X[w, rng.integers(WIN), c]
        elif kind == 2:
            X[w, :, c] += np.linspace(0, amp * rng.uniform(1, 2), WIN) * rng.choice([-1, 1])
        else:
            X[w, :, c] += rng.normal(0, amp / 2, WIN)
    return features(X), y


def build_dataset_intel(seed, rate_scale=1.0, alpha=0.5):
    """Each seed starts at a different day of the trace and draws its own fault process.
    Per mote: the first 200 clean windows after the start are training data, the next 100 test data."""
    z = np.load('intel_windows.npz'); motes = z['motes']
    rng = np.random.default_rng(seed)
    prof = make_node_profiles(rng, n=len(motes), rate_scale=rate_scale, alpha=alpha)
    t0 = (seed - 1) * 86400.0
    tr, te = [], []
    for m, p in zip(motes, prof):
        X, t = z[f'X{m}'], z[f't{m}']
        k = int(np.searchsorted(t, t0))
        k = min(k, len(X) - N_TRAIN - N_TEST)
        tr.append(inject(rng, X[k:k + N_TRAIN], p))
        te.append(inject(rng, X[k + N_TRAIN:k + N_TRAIN + N_TEST], p))
    allX = np.concatenate([x for x, _ in tr])
    mu, sd = allX.mean(0), allX.std(0) + 1e-6
    tr = [((x - mu) / sd, y) for x, y in tr]
    te = [((x - mu) / sd, y) for x, y in te]
    return prof, tr, te


if __name__ == '__main__':
    preprocess(*sys.argv[1:4])
