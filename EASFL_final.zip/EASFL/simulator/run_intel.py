"""Real-data experiment on the Intel Berkeley Research Lab deployment (see intel.py).
Real readings with injected faults, real mote positions, measured link qualities with up to three
802.15.4 retransmissions. Writes results_intel.json; summarize_intel.py prints the tables."""
import json, sys, time
import numpy as np
from multiprocessing import Pool
import common
from common import init_params, sgd, metrics, predict_proba, best_threshold
from sim import Sim
from run_quick import lifetime
from intel import build_dataset_intel, load_net

SEEDS = [1, 2, 3, 4, 5]
R_LEARN = 200
PERS = [None, 'thr', 'ft+thr']
ATTACKS = ['signflip', 'stealth', 'labelflip', 'gauss']


def key(p):
    return 'global' if p is None else p


def learn_run(args):
    scheme, seed, kw = args
    common.set_radio('first-order')
    net = load_net(); data = build_dataset_intel(seed)
    s = Sim(scheme, seed, learn=True, data=data, net=net, **kw)
    for _ in range(R_LEARN):
        s.step()
    final = {key(p): s.evaluate(p) for p in PERS}
    final['net'] = s.evaluate('ft+thr', alive_only=True)
    return dict(scheme=scheme, seed=seed, kw=kw, final=final, mbit=s.bits_up / 1e6,
                energy=float(s.E0.sum() - np.clip(s.E, 0, None).sum()), alive=int((s.E > 0).sum()))


def central_run(seed):
    _, tr, te = build_dataset_intel(seed)
    X = np.concatenate([x for x, _ in tr]); y = np.concatenate([t for _, t in tr])
    rng = np.random.default_rng(seed); w = init_params(rng)
    for _ in range(30):
        w = sgd(w, X, y, rng, 1, 0.05, 32)
    out = {'global': metrics(w, te)}
    P = []
    for (Xt, yt), (Xe, _) in zip(tr, te):
        t = best_threshold(predict_proba(w, Xt), yt)
        P.append(np.clip(predict_proba(w, Xe) - t + 0.5, 0, 1))
    out['thr'] = metrics(None, te, proba=np.concatenate(P))
    return dict(seed=seed, final=out)


def local_run(seed):
    _, tr, te = build_dataset_intel(seed)
    rng = np.random.default_rng(seed); P, Pt = [], []
    for (X, y), (Xe, _) in zip(tr, te):
        w = init_params(rng)
        for _ in range(30):
            w = sgd(w, X, y, rng, 1, 0.05, 16)
        p = predict_proba(w, Xe); P.append(p)
        t = best_threshold(predict_proba(w, X), y); Pt.append(np.clip(p - t + 0.5, 0, 1))
    return dict(seed=seed, final={'global': metrics(None, te, proba=np.concatenate(P)),
                                  'thr': metrics(None, te, proba=np.concatenate(Pt))})


def life_run(args):
    radio, scheme, seed, kw = args
    common.set_radio(radio)
    net = load_net()
    r = lifetime(scheme, seed, maxr=20000, net=net, **kw)
    s = Sim(scheme, seed, net=net, **kw)
    for _ in range(10):
        s.step()
    e = {k: v / 10 / s.n for k, v in s.ecat.items()}
    return dict(radio=radio, scheme=scheme, seed=seed, kw=kw, fnd=r['fnd'], hnd=r['hnd'], lnd=r['lnd'], energy=e)


if __name__ == '__main__':
    t = time.time()
    out = {}
    with Pool(2) as pool:
        out['central'] = pool.map(central_run, SEEDS)
        out['local'] = pool.map(local_run, SEEDS)
        out['learn'] = pool.map(learn_run, [(sc, sd, {}) for sc in ['FL-flat', 'FL-LEACH', 'EASFL'] for sd in SEEDS])
        print('learn', round(time.time() - t), flush=True)
        jobs = []
        for a in ATTACKS:
            for sc, kw in [('FL-LEACH', {}), ('FL-LEACH', {'agg': 'median'}), ('FL-LEACH', {'agg': 'trimmed'}),
                           ('FL-LEACH', {'agg': 'krum'}), ('EASFL', {})]:
                for sd in SEEDS:
                    jobs.append((sc, sd, dict(kw, mal_frac=0.2, attack=a)))
        out['attack'] = pool.map(learn_run, jobs)
        print('attack', round(time.time() - t), flush=True)
        variants = [('CL', {}), ('FL-flat', {}), ('FL-LEACH', {}), ('EASFL', {}), ('EASFL', {'pd': True})]
        out['life'] = pool.map(life_run, [(rad, sc, sd, kw) for rad in ['first-order', 'CC2420', 'CC2650']
                                          for sc, kw in variants for sd in SEEDS])
        print('life', round(time.time() - t), flush=True)
    json.dump(out, open('results_intel.json', 'w'), default=float)
